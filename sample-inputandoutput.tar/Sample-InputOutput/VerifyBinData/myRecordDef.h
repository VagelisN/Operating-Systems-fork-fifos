#define SIZEofBUFF 20
#define SSizeofBUFF 6

typedef struct{
	float	x;  	
	float	y;
} MyRecord;

